CREATE TABLE socios(
	nrosocio INTEGER,
	nombres VARCHAR(30),
	apellidos VARCHAR(30),
	ci INTEGER UNIQUE,
	edad INTEGER,
	socioproponente INTEGER,

	CONSTRAINT Pks PRIMARY KEY(nrosocio),
	CONSTRAINT Fksp FOREIGN KEY(socioproponente) REFERENCES socios(nrosocio),
	CONSTRAINT ckedad CHECK (edad>18)
);

CREATE SEQUENCE seq_nrosocio
start with 1
increment by 1;


CREATE TABLE prestamo(
	nroprestamo INTEGER,
	nrosocio INTEGER,
	fecha DATE,
	tasa NUMBER(2,1),
	monto INTEGER,
	saldo INTEGER,

	CONSTRAINT Pkp PRIMARY KEY(nroprestamo),
	CONSTRAINT Fkps FOREIGN KEY(nrosocio) REFERENCES socios(nrosocio),
	CONSTRAINT ckmonto CHECK (monto>0)
);

CREATE SEQUENCE seq_nroprestamo
start with 1
increment by 1;

CREATE TABLE cuota(
	nroprestamo INTEGER,
	nrocuota INTEGER,
	fecha_vence DATE,
	fecha_pago DATE,
	importe INTEGER,

	CONSTRAINT Fkpc FOREIGN KEY(nroprestamo) REFERENCES prestamo(nroprestamo),
	CONSTRAINT ckimporte CHECK (importe>0)
);

ALTER SESSION SET NLS_DATE_FORMAT = 'dd/mm/yyyy'; 

CREATE TRIGGER Verificar_fecha_cuota
BEFORE UPDATE OF fecha_pago ON cuota
FOR EACH ROW
BEGIN
	IF(:new.fecha_pago > :old.fecha_vence) THEN
		raise_application_error(-2001,'Cuota Vencida');
	ELSE
		UPDATE prestamo SET saldo = saldo -:old.importe WHERE(nroprestamo = :old.nroprestamo);
	END IF;
END Verificar_fecha_cuota;

insert into socios values(seq_nrosocio.nextval,'Luis','Acosta',1111,25,null);
insert into socios values(seq_nrosocio.nextval,'Pedro','Rivaldi',2222,19,1);
insert into socios values(seq_nrosocio.nextval,'Laura','Diaz',33,3333,1);
insert into socios values(seq_nrosocio.nextval,'Leticia','Perez',4444,23,2);

insert into prestamo values (seq_nroprestamo.nextval,1,'01/02/2017',1.2,1000000,0);
insert into prestamo values (seq_nroprestamo.nextval,2,'01/04/2017',1.2,1000000,500000);
insert into prestamo values (seq_nroprestamo.nextval,2,'05/04/2017',1.2,1000000,1000000);
insert into prestamo values (seq_nroprestamo.nextval,1,'01/05/2017',1.2,1000000,1000000);

insert into cuota values(1,1,'01/03/2017','25/02/2017',500000);
insert into cuota values(1,2,'01/04/2017','30/03/2017',500000);
insert into cuota values(2,1,'01/05/2017','25/04/2017',500000);
insert into cuota values(2,2,'01/06/2017',null,500000);
insert into cuota values(3,1,'05/05/2017',null,500000);
insert into cuota values(3,2,'05/06/2017',null,500000);
insert into cuota values(4,1,'01/06/2017',null,500000);
insert into cuota values(4,2,'01/07/2017',null,500000);

CREATE OR REPLACE VIEW Vista_Socios
(NroSocio, NombreyApellido, CI, Total_Prestamo_Obtenido, Total_Prestamo_Cancelado, SocioProponente)
AS
SELECT s1.nrosocio,
s1.nombres || ' ' || s1.apellidos,
s1.ci,
(SELECT SUM(p.monto)FROM prestamo p WHERE p.nrosocio = s1.nrosocio),
(SELECT SUM(pc.monto)FROM prestamo pc WHERE (pc.nrosocio = s1.nrosocio and pc.saldo = 0)),
s2.nombres || ' ' || s2.apellidos
from socios s1
left join socios s2 on s1.socioproponente = s2.nrosocio
order by s1.nrosocio;

